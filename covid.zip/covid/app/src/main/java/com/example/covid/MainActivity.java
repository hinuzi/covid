package com.example.covid;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {
    private Button button;
    private String TAG = MainActivity.class.getSimpleName();

    private ProgressDialog pDialog;
    private ListView lv;

    private static String url = "https://indonesia-covid-19.mathdro.id/api/provinsi/";

    //ArrayList<HashMap<String, String>> contactList;
    ArrayList<HashMap<String, String>> covidList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.covid1);
        button = (Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                openCovidList();
            }
        });
        //contactList = new ArrayList<>();
        covidList = new ArrayList<>();

        lv = (ListView) findViewById(R.id.list);

        new GetCovid().execute();
    }
    public void openCovidList(){
    Intent intent = new Intent(this, CovidList.class);
    startActivity(intent);
    }

    /**
     * Async task class to get json by making HTTP call
     */
    private class GetCovid extends AsyncTask<Void, Void, Void> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // Showing progress dialog
            pDialog = new ProgressDialog(MainActivity.this);
            pDialog.setMessage("Please wait...");
            pDialog.setCancelable(false);
            pDialog.show();

        }
        @Override
        protected Void doInBackground(Void... arg0) {
            CovidList sh = new CovidList();

            // Making a request to url and getting response
            String jsonStr = sh.makeServiceCall(url);

            Log.e(TAG, "Response from url: " + jsonStr);

            if (jsonStr != null) {
                try {
                    JSONObject jsonObj = new JSONObject(jsonStr);

                    // Getting JSON Array node
                    JSONArray contacts = jsonObj.getJSONArray("data");

                    // looping through All Contacts
                    for (int i = 0; i < contacts.length(); i++) {
                        JSONObject c = contacts.getJSONObject(i);

                        String fid = c.getString("fid");
                        String kodeprovinsi = c.getString("kodeProvi");
                        String provinsi = c.getString("provinsi");
                        String positif = c.getString("kasusPosi");
                        String sembuh = c.getString("kasusSemb");
                        String meninggal = c.getString("kasusMeni");

                        /*
                        // Phone node is JSON Object
                        JSONObject phone = c.getJSONObject("phone");
                        String mobile = phone.getString("mobile");
                        String home = phone.getString("home");
                        String office = phone.getString("office");
                         */

                        // tmp hash map for single contact
                        HashMap<String, String> contact = new HashMap<>();

                        // adding each child node to HashMap key => value
                        contact.put("fid", fid);
                        contact.put("kodeprovinsi", kodeprovinsi);
                        contact.put("provinsi", provinsi);
                        contact.put("positif", positif);
                        contact.put("sembuh", sembuh);
                        contact.put("meninggal", meninggal);

                        // adding contact to contact list
                        covidList.add(contact);
                    }
                } catch (final JSONException e) {
                    Log.e(TAG, "Json parsing error: " + e.getMessage());
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(),
                                    "Json parsing error: " + e.getMessage(),
                                    Toast.LENGTH_LONG)
                                    .show();
                        }
                    });

                }
            } else {
                Log.e(TAG, "Couldn't get json from server.");
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(getApplicationContext(),
                                "Couldn't get json from server. Check LogCat for possible errors!",
                                Toast.LENGTH_LONG)
                                .show();
                    }
                });

            }

            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            // Dismiss the progress dialog
            if (pDialog.isShowing())
                pDialog.dismiss();
            /**
             * Updating parsed JSON data into ListView
             * */
            ListAdapter adapter = new SimpleAdapter(
                    MainActivity.this, covidList,
                    R.layout.covid2,
                    new String[]{"provinsi", "positif","sembuh", "meninggal"},
                    new int[]{R.id.name,R.id.email, R.id.mobile, R.id.mobile2});

            lv.setAdapter(adapter);
        }

    }
}